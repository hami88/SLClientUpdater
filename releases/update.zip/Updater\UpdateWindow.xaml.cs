﻿using System.Windows;
using System.Windows.Media.Imaging;
using WpfAnimatedGif;

namespace SLClient.Updater;

public partial class UpdateWindow : Window
{
    public UpdateWindow()
    {
        InitializeComponent();

        var imagePath = new Uri("pack://application:,,,/Assets/coding.gif", UriKind.Absolute);
        var image = new BitmapImage(imagePath);
        ImageBehavior.SetAnimatedSource(GifImage, image);
    }

    public void SetVersionInfo(string current, string latest)
    {
        VersionText.Text = $"Installiert: {current}   ➜   Verfügbar: {latest}";
    }

    public void SetProgress(int percent)
    {
        Progress.Value = percent;
    }

    public void SetStatus(string text)
    {
        StatusText.Text = text;
    }
}
